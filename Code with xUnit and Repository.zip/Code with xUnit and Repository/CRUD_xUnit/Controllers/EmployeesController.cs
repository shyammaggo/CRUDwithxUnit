﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CRUD.API.Data;
using CRUD.API.Domain;
using CRUD.API.Contracts;
using CRUD.BusinessObjects;

namespace CRUD.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly EmployeeContext _context;
        private readonly IEmployeeService _service;
        private readonly IEmployeeBO _boEmployee;
        //public EmployeesController(EmployeeContext context)
        public EmployeesController(IEmployeeService service)
       // public EmployeesController(IEmployeeBO boEmployee)
        {
            //=_context = context;
            _service = service;
            //_boEmployee = boEmployee;
        }

        // GET: api/Employees
        [HttpGet]
        // public async Task<ActionResult<IEnumerable<Employee>>> GetEmployees()
        public ActionResult<IEnumerable<Employee>> GetEmployees()
        {
            //    return await _context.Employee.ToListAsync();
            var items = _service.GetAllEmployeess();
            //var items = _boEmployee.GetAllEmployeess();
            return Ok(items);
        }

        // GET: api/Employees/5
        [HttpGet("{id}")]
        //public async Task<ActionResult<Employee>> GetEmployee(int id)
        public ActionResult<Employee> GetEmployee(int id)
        {
            var employee = _service.GetById(id);// await _context.Employee.FindAsync(id);
            //var employee = _boEmployee.GetById(id);
            if (employee == null)
            {
                return NotFound();
            }

            return Ok(employee);
        }
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        // public async Task<ActionResult<Employee>> PostEmployee(Employee employee)
        public ActionResult PostEmployee([FromBody] Employee employee)
        {
            //_context.Employee.Add(employee);
            //  _context.SaveChangesAsync();
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            //if (employee.Name==null)
            //{
            //    return BadRequest("Name is required.");
            //}
            employee= _service.Add(employee);
            //employee = _boEmployee.Add(employee);
            return CreatedAtAction("GetEmployee", new { id = employee.Id }, employee);
        }
      

        // POST: api/Employees
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
       

        // DELETE: api/Employees/5
        [HttpDelete("{id}")]
        public ActionResult DeleteEmployee(int id)
        {
            // var employee =  _context.Employee.Find(id);
            var employee = _service.GetById(id);// await _context.Employee.FindAsync(id);

            if (employee == null)
            {
                return NotFound();
            }
            _service.Remove(id);

            return Ok(employee);
           
            if (employee == null)
            {
                return NotFound();
            }

            _context.Employee.Remove(employee);
              _context.SaveChanges();

            return Ok();
        }
        // PUT: api/Employees/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public    IActionResult   PutEmployee(int id, Employee employee)
        {
            if (id != employee.Id)
            {
                return BadRequest();
            }
            try
            {
                 _service.Update(employee);
                //_boEmployee.Update(employee);
            }
            catch (ApplicationException ex)
            {
                if (ex.Message == "Not Found")
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
            //_context.Entry(employee).State = EntityState.Modified;

            //try
            //{
            //    await _context.SaveChangesAsync();
            //}
            //catch (DbUpdateConcurrencyException)
            //{
            //    if (!EmployeeExists(id))
            //    {
            //        return NotFound();
            //    }
            //    else
            //    {
            //        throw;
            //    }
            //}

            //return NoContent();
        }
        private bool EmployeeExists(int id)
        {
            return _context.Employee.Any(e => e.Id == id);
        }
    }
}
