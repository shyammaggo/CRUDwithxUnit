﻿using System;

namespace CRUD_BusinessObjects
{
    public class Class1
    {
    }
}
